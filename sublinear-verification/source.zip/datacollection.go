package main

import (
	"encoding/csv"
	"fmt"
	"log"
	"os"
	"strconv"
)

func exportCSV(title string, data [][]string) {
	file, err := os.Create(title)
	checkError("Cannot create file", err)
	defer file.Close()

	writer := csv.NewWriter(file)
	defer writer.Flush()

	for _, v := range data {
		err := writer.Write(v)
		checkError("Cannot write to file", err)
	}
}

func checkError(message string, err error) {
	if err != nil {
		log.Fatal(message, err)
	}
}

func sTest(which int, step int, max int, avg int) [][]string {

	result := [][]string{}
	if which == 0 {
		result = append(result, []string{"Simple Payment Verification"})
	} else if which == 1 {
		result = append(result, []string{"Sublinear Complexity Verification"})
	} else {
		fmt.Println("which needs to be 0 or 1")
	}
	iter := int(max / step)
	testchain := BlockChain{}
	testchain.Init()
	testchain.GenerateBlocks(max)

	for i := 1; i <= iter; i++ {
		s := ""
		sum := 0
		for j := 0; j < avg; j++ {

			if which == 0 {
				sum += SimplePaymentVerification(testchain.LightClient, i*step)
			} else if which == 1 {
				sum += SublinearComplexityVerification(testchain.LightClient, i*step)
			} else {
				fmt.Println("which needs to be 0 or 1")
				sum += 0
			}
		}
		s = strconv.Itoa(sum / avg)
		row := []string{s}
		//scv := strconv.FormatInt(SublinearComplexityVerification(testchain.LightClient, i*step), 10)
		result = append(result, row)
	}
	return result
}
