package main

// FindPrevLevelBlockIndex will take in a block index and
// RETURN the block index of theh closest higher level block
func FindPrevLevelBlockIndex(lc []BlockHeader, n int) int {
	if n < 2 {
		return 0
	}
	result := n
	for lc[n].Level >= lc[result].Level {
		result--
	}
	return result
}
