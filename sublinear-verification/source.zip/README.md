# PART1 - Sublinear complexity verification 
Assumptions – blocks are added by a valid consensus algorithm