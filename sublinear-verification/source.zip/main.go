package main

//"fmt"

func main() {
	//testchain := BlockChain{}
	//testchain.Init()
	//fmt.Println(testchain.LightClient)
	//testchain.GenerateBlocks(100)
	//	testchain.GenerateBlocks(100)
	//testchain.PrintBlockChain()
	//	SimplePaymentVerification(testchain.LightClient, 200)
	//	SublinearComplexityVerification(testchain.LightClient, 200)
	//fmt.Println(testchain.FindPrevLevelBlock(5))
	//fmt.Println(testchain.LightClient[5].LevelPrevHash)
	exportCSV("spv.csv", sTest(0, 100, 10000, 100))
	exportCSV("scv.csv", sTest(1, 100, 10000, 100))
}
