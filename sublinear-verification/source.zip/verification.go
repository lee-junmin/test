package main

import (
	"time"
)

// SimplePaymentVerification will verify a given block
// takes in a block index and RETURN true if the block is valid
func SimplePaymentVerification(lc []BlockHeader, index int) int {
	start := time.Now()
	for index > 0 {

		if lc[index].PrevHash == lc[index-1].Hash {
			//time.Sleep(time.Nanosecond)
			index--
		} else {
			return 0
		}

	}
	//return fmt.Sprintf("%s", time.Since(start))
	return timeFormatMicro(time.Since(start))
}

// SublinearComplexityVerification will verify a given block based on the level
// takes in a block index and RETURN true if the block is valid
func SublinearComplexityVerification(lc []BlockHeader, index int) int {
	start := time.Now()
	for index > 0 {

		prevLevelIndex := FindPrevLevelBlockIndex(lc, index)
		if lc[index].LevelPrevHash == lc[prevLevelIndex].Hash {
			//fmt.Println("verification path", index, lc[prevLevelIndex].Index, lc[prevLevelIndex].Level)
			index = prevLevelIndex
			//time.Sleep(time.Nanosecond)
		} else {
			return 0
		}
	}
	//return fmt.Sprintf("%s", time.Since(start))
	//return fmt.Sprintf("%s", timeFormatMicro(time.Since(start)))
	return timeFormatMicro(time.Since(start))
}

func timeFormatMicro(t time.Duration) int {
	return int(t)
}
